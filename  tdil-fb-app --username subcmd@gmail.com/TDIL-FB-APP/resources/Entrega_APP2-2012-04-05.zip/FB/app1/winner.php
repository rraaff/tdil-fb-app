<html>
<head>
<link href="../css/tdil.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
body {
	background-image: url(../images/winner.jpg);
	background-repeat: no-repeat;
	background-position: left top;
	overflow:hidden !important;
}
#textContent{
	width: 500px;
	margin-top: 460px;
	margin-right: auto;
	margin-left: auto;
	text-align: center;
}
</style>
</head>
<body>
<div id="textContent">winnername : <?php echo $winnerame;?><br>winnerid : <?php echo $winnerfbid;?><br>winnerusername : <?php echo $winnerusername;?><br></div>
</body>
</html>

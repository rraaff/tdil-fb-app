<?php
	header("Content-type: text/html; charset=utf-8");
	// Date in the past
	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	header("Cache-Control: no-cache, must-revalidate");
	header("Pragma: no-cache");
?>
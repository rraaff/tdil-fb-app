-- Este query se usa para insertar los usuarios de backoffice

INSERT INTO BOUSER(nombre, apellido, email, usuario, password)
VALUES ('fb', 'fb', 'fb@ssdd.com', 'fb', 'fb'); 

INSERT INTO BOUSER(nombre, apellido, email, usuario, password)
VALUES ('pablo', 'mendoza', 'aas@ssdd.com', 'pm', 'pm'); 
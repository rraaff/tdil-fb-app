--Estos inserts son los inserts iniciales a la base

INSERT INTO USER_APP1(inv_email,origin,participation) VALUES ('a',1,0);
INSERT INTO USER_APP1(inv_email,origin,participation) VALUES ('b',1,0);  
INSERT INTO USER_APP1(inv_email,origin,participation) VALUES ('c',1,0);
INSERT INTO USER_APP1(inv_email,origin,participation) VALUES ('d',1,0);
INSERT INTO USER_APP1(inv_email,origin,participation) VALUES ('e',1,0);  
INSERT INTO USER_APP1(inv_email,origin,participation) VALUES ('f',1,0);
INSERT INTO USER_APP1(inv_email,origin,participation) VALUES ('g',1,0);
INSERT INTO USER_APP1(inv_email,origin,participation) VALUES ('h',1,0);  
INSERT INTO USER_APP1(inv_email,origin,participation) VALUES ('i',1,0);
INSERT INTO USER_APP1(inv_email,origin,participation) VALUES ('j',1,0);
INSERT INTO USER_APP1(inv_email,origin,participation) VALUES ('k',1,0);  
INSERT INTO USER_APP1(inv_email,origin,participation) VALUES ('h',1,0);
INSERT INTO USER_APP1(inv_email,origin,participation) VALUES ('i',1,0);
INSERT INTO USER_APP1(inv_email,origin,participation) VALUES ('l',1,0);  
INSERT INTO USER_APP1(inv_email,origin,participation) VALUES ('m',1,0);
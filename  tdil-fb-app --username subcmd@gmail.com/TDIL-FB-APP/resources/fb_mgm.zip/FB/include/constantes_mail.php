<?php		
	//Defino las constantes para envio de email
	define('SERVER_NAME','http://arlistan.ccc'); // server name, usado para reemplazo en los mails
	define('EMAIL_FROM_APP1','mgodoy@mgodoy.com'); // email from para las invitaciones
	define('EMAIL_FROM_NAME_APP1','Arlistan'); // name del email from para las invitaciones
	
	define('APP1_SUMATE_SUBJECT','Sumate a mi grupo'); // subject para la invitacion de un owner a otro usuarios
	define('APP1_WINNER_SUBJECT','Ganaste'); // mail de ganador (ojo, quizas este circuito habrian que eliminarlo)
	
	define('BODY_ALT','Para ver correctamente este email usar un visor html.');
	
?>
<?php		
	//Defino las constantes para la base de datos
	define('DB_SERVER','localhost'); // server de la base de datos
	define('DB_USER','FB_MGM_USER'); // usuario de la base de datos
	define('DB_PASS','FB_MGM_USER'); // password de la base de datos
	define('DB_NAME','FB_MGM'); // schema de la base de datos
?>
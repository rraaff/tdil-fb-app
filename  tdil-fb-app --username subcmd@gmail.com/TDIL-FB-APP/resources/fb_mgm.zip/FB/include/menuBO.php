<script type="text/javascript">
  jQuery(function(){ 
    jQuery('.jbar').jbar();
  });
</script>

<ul class="jbar">
   <li>
    <a href="#">App 10x10=17</a>
    <ul>
      <li><a href="boApp1Config.php">Configuracion de la applicacion</a></li>
      <li><a href="boApp1Stats.php">Estado de la applicacion</a></li>
      <li><a href="boApp1Search.php">Consultas</a></li>
    </ul>
  </li>
  <li>
    <a href="boLogout.php">Salir</a>
  </li>
</ul>
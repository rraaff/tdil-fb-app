<!-- {PABLO} Esta pagina es la que se muestra a los que son miembros de un grupo -->
Sos miembro del grupo de <?php echo $group_owner_name;?>
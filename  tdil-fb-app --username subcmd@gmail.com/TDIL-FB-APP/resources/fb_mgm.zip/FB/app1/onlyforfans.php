<?php
	/* Pagina que dice que la app es solo para fans*/
?>
<html>
<body>
<img src="../images/onlyforfans.jpg" width="795" height="780">
</body>
</html>
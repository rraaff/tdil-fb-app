<?php 
/** {PABLO} Esta pagina se muestra cuando hay un ganador, queda como home */
?>
winnername : <?php echo $winnerame;?><br>
winnerid : <?php echo $winnerfbid;?><br>
winnerusername : <?php echo $winnerusername;?><br>